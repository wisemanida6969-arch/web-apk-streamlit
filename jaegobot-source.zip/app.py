import os
from flask import Flask
from flask_login import LoginManager
from dotenv import load_dotenv

# Load .env file automatically
load_dotenv()

from models import db, User
from routes.auth import auth_bp
from routes.inventory import inventory_bp


def create_app():
    app = Flask(__name__)

    # ─── Config ───
    app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-secret-change-me")
    app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get(
        "DATABASE_URL", "sqlite:///jaegobot.db"
    )
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    # ─── Extensions ───
    db.init_app(app)

    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = "auth.login"
    login_manager.login_message = "로그인이 필요합니다."
    login_manager.login_message_category = "error"

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    # ─── Blueprints ───
    app.register_blueprint(auth_bp)
    app.register_blueprint(inventory_bp)

    # ─── Create tables ───
    with app.app_context():
        db.create_all()

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=True)
