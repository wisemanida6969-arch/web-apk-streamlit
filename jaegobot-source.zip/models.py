from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    restaurant_name = db.Column(db.String(100))
    plan = db.Column(db.String(20), default="free")  # free, basic, pro
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    menu_items = db.relationship("MenuItem", backref="user", lazy=True, cascade="all, delete-orphan")
    predictions = db.relationship("Prediction", backref="user", lazy=True, cascade="all, delete-orphan")

    def set_password(self, password: str) -> None:
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)


class MenuItem(db.Model):
    __tablename__ = "menu_items"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    current_stock = db.Column(db.Float, default=0)
    unit = db.Column(db.String(20), default="개")
    min_stock = db.Column(db.Float, default=0)  # 최소 재고 (알림용)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    @property
    def is_low(self) -> bool:
        return self.current_stock <= self.min_stock


class Prediction(db.Model):
    __tablename__ = "predictions"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    date = db.Column(db.Date, default=datetime.utcnow)
    result = db.Column(db.Text)  # 날씨/재고 스냅샷
    ai_analysis = db.Column(db.Text)  # Claude 분석 결과
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
