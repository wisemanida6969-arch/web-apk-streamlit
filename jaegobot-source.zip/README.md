# 🤖 재고봇 (JaegoBot)

AI-powered inventory management for restaurants. 날씨 기반 재고 예측 + Claude AI 분석.

## Features

- 🔐 **회원가입/로그인** — Flask-Login 기반 인증
- 📦 **재고 관리** — 메뉴별 현재/최소 재고 관리
- 🌤️ **실시간 날씨** — OpenWeatherMap API 연동
- 🤖 **AI 예측** — Claude Haiku로 오늘의 수요/발주 분석
- 📊 **대시보드** — 재고 현황 + AI 분석 결과 한눈에

## Tech Stack

- **Backend:** Flask 3 + SQLAlchemy (SQLite)
- **Auth:** Flask-Login + Werkzeug password hashing
- **APIs:** OpenWeatherMap, Anthropic Claude
- **Frontend:** Jinja2 + Vanilla CSS (모바일 반응형)
- **Deploy:** Gunicorn + Render/Heroku ready

## Local Development

```bash
# 1. 의존성 설치
pip install -r requirements.txt

# 2. 환경변수 설정
cp .env.example .env
# .env 파일에 API 키 입력

# 3. 실행
python app.py
# → http://localhost:5000
```

### 필요한 API 키

| 서비스 | 발급 | 비용 |
|--------|-----|------|
| [OpenWeatherMap](https://openweathermap.org/api) | 무료 가입 | Free (60 calls/min) |
| [Anthropic Claude](https://console.anthropic.com) | API 키 발급 | 사용량 기반 |

## Deploy to Render (1-click)

1. **GitHub에 push** (아래 단계 참조)
2. [render.com](https://render.com) 가입
3. **New → Blueprint** 선택
4. GitHub 저장소 연결
5. `render.yaml` 자동 감지됨
6. **ANTHROPIC_API_KEY** 환경변수만 입력
7. Deploy 클릭 → 완료!

OpenWeather 키는 `render.yaml`에 포함되어 있어서 자동 설정됩니다.

## Project Structure

```
재고봇/
├── app.py              # Flask 엔트리포인트
├── models.py           # SQLAlchemy 모델 (User, MenuItem, Prediction)
├── routes/
│   ├── auth.py         # 인증 라우트
│   └── inventory.py    # 재고/예측 라우트
├── templates/          # Jinja2 템플릿
├── static/             # CSS/이미지
├── requirements.txt    # Python 의존성
├── Procfile            # 배포 명령
├── render.yaml         # Render one-click 설정
└── runtime.txt         # Python 버전
```

## License

MIT
