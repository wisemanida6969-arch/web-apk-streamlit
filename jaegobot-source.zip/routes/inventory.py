import os
from datetime import datetime

import requests
from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_required, current_user

from models import db, MenuItem, Prediction

inventory_bp = Blueprint("inventory", __name__)

OPENWEATHER_API_KEY = os.environ.get("OPENWEATHER_API_KEY", "")
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
DEFAULT_CITY = os.environ.get("DEFAULT_CITY", "Seoul")


# ─── External APIs ───

def get_weather(city: str = DEFAULT_CITY):
    """Fetch current weather from OpenWeatherMap."""
    if not OPENWEATHER_API_KEY:
        return None
    try:
        url = "https://api.openweathermap.org/data/2.5/weather"
        resp = requests.get(
            url,
            params={
                "q": city,
                "appid": OPENWEATHER_API_KEY,
                "units": "metric",
                "lang": "kr",
            },
            timeout=10,
        )
        resp.raise_for_status()
        data = resp.json()
        return {
            "city": city,
            "temp": round(data["main"]["temp"], 1),
            "description": data["weather"][0]["description"],
            "humidity": data["main"]["humidity"],
            "wind": data["wind"]["speed"],
        }
    except Exception as e:
        print(f"[Weather] fetch error: {e}")
        return None


def get_ai_prediction(menu_items, weather, restaurant_name: str = ""):
    """Ask Claude to analyze inventory vs weather and predict today's sales."""
    if not ANTHROPIC_API_KEY:
        return "⚠️ Claude API 키가 설정되지 않았습니다. 환경변수 ANTHROPIC_API_KEY를 설정하세요."

    items_text = "\n".join(
        [f"- {m.name}: 현재 {m.current_stock}{m.unit} (최소 {m.min_stock}{m.unit})" for m in menu_items]
    )

    if weather:
        weather_text = (
            f'{weather["city"]}, {weather["temp"]}°C, {weather["description"]}, '
            f'습도 {weather["humidity"]}%, 풍속 {weather["wind"]}m/s'
        )
    else:
        weather_text = "날씨 정보 없음"

    prompt = f"""당신은 식당 재고 관리 전문 AI입니다. 아래 정보를 바탕으로 오늘의 예상 판매량과 재고 관리 조언을 해주세요.

식당명: {restaurant_name or "미등록"}
오늘의 날씨: {weather_text}

현재 재고:
{items_text}

다음 형식으로 답변해주세요:
1. **오늘의 예상 수요** (날씨를 고려하여 어떤 메뉴가 잘 나갈지)
2. **재고 부족 경고** (현재 재고로 부족할 가능성이 있는 메뉴)
3. **추가 발주 추천** (오늘 추가로 준비해야 할 재료)
4. **한 줄 조언** (오늘 운영 팁)

한국어로 간결하고 실용적으로 답변해주세요."""

    try:
        resp = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": "claude-haiku-4-5-20251001",
                "max_tokens": 1500,
                "messages": [{"role": "user", "content": prompt}],
            },
            timeout=30,
        )
        resp.raise_for_status()
        return resp.json()["content"][0]["text"]
    except Exception as e:
        return f"AI 분석 실패: {e}"


# ─── Routes ───

@inventory_bp.route("/")
def index():
    if current_user.is_authenticated:
        return redirect(url_for("inventory.dashboard"))
    return redirect(url_for("auth.login"))


@inventory_bp.route("/dashboard")
@login_required
def dashboard():
    menu_items = MenuItem.query.filter_by(user_id=current_user.id).order_by(MenuItem.name).all()
    weather = get_weather()
    latest_prediction = (
        Prediction.query.filter_by(user_id=current_user.id)
        .order_by(Prediction.created_at.desc())
        .first()
    )
    low_stock_count = sum(1 for m in menu_items if m.is_low)

    return render_template(
        "dashboard.html",
        menu_items=menu_items,
        weather=weather,
        prediction=latest_prediction,
        low_stock_count=low_stock_count,
    )


@inventory_bp.route("/inventory", methods=["GET", "POST"])
@login_required
def inventory():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        stock = request.form.get("stock", type=float) or 0
        unit = request.form.get("unit", "개").strip() or "개"
        min_stock = request.form.get("min_stock", type=float) or 0

        if not name:
            flash("메뉴명을 입력해주세요.", "error")
            return redirect(url_for("inventory.inventory"))

        item = MenuItem(
            user_id=current_user.id,
            name=name,
            current_stock=stock,
            unit=unit,
            min_stock=min_stock,
        )
        db.session.add(item)
        db.session.commit()
        flash(f"{name} 추가 완료", "success")
        return redirect(url_for("inventory.inventory"))

    menu_items = MenuItem.query.filter_by(user_id=current_user.id).order_by(MenuItem.name).all()
    return render_template("inventory.html", menu_items=menu_items)


@inventory_bp.route("/inventory/update/<int:item_id>", methods=["POST"])
@login_required
def update_item(item_id):
    item = MenuItem.query.get_or_404(item_id)
    if item.user_id != current_user.id:
        flash("권한이 없습니다.", "error")
        return redirect(url_for("inventory.inventory"))

    item.current_stock = request.form.get("stock", type=float) or 0
    db.session.commit()
    flash(f"{item.name} 재고 업데이트 완료", "success")
    return redirect(url_for("inventory.inventory"))


@inventory_bp.route("/inventory/delete/<int:item_id>", methods=["POST"])
@login_required
def delete_item(item_id):
    item = MenuItem.query.get_or_404(item_id)
    if item.user_id != current_user.id:
        flash("권한이 없습니다.", "error")
        return redirect(url_for("inventory.inventory"))

    name = item.name
    db.session.delete(item)
    db.session.commit()
    flash(f"{name} 삭제 완료", "success")
    return redirect(url_for("inventory.inventory"))


@inventory_bp.route("/predict", methods=["POST"])
@login_required
def predict():
    menu_items = MenuItem.query.filter_by(user_id=current_user.id).all()
    if not menu_items:
        flash("먼저 메뉴를 등록해주세요.", "error")
        return redirect(url_for("inventory.inventory"))

    weather = get_weather()
    ai_result = get_ai_prediction(menu_items, weather, current_user.restaurant_name or "")

    snapshot = "\n".join(
        [f"{m.name}: {m.current_stock}{m.unit}" for m in menu_items]
    )
    if weather:
        snapshot = (
            f"{weather['temp']}°C / {weather['description']}\n\n{snapshot}"
        )

    prediction = Prediction(
        user_id=current_user.id,
        date=datetime.utcnow().date(),
        result=snapshot,
        ai_analysis=ai_result,
    )
    db.session.add(prediction)
    db.session.commit()

    flash("🤖 AI 예측 완료!", "success")
    return redirect(url_for("inventory.dashboard"))
